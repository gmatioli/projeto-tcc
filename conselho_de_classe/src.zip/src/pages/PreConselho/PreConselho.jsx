import React, { useState,  useEffect, useCallback  } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom'
import { toast } from 'sonner';
import totalAlunosIcon from '../../assets/pre-conselho/total-alunos-icon.svg'
import situacaoNormalIcon from '../../assets/pre-conselho/situacao-normal-icon.svg'
import restritosIcon from '../../assets/pre-conselho/restritos-icon.svg'
import retidosIcon from '../../assets/pre-conselho/retidos-icon.svg'
import notificationIcon from '../../assets/pre-conselho/notification-icon.svg'

import ModalAvaliacao from '../../components/modalAvaliacaoPreConselho/ModalAvaliacao';
 
// ── Modal: Ver Observações ─────────────────────────────────────────────────
import ModalObservacoes from '../../components/modalObservacao/ModalObservacao';

import { API, authFetch } from '../../config/api';

// Calcula semestre/ano corrente (mês <= 6 => 1º semestre)
const cicloAtual = () => {
  const hoje = new Date();
  const mes = hoje.getMonth() + 1;       
//   const mes = 8;
  return {
    ano: hoje.getFullYear(),
    semestre: mes <= 6 ? 1 : 2
  };
};

  const cardInfo = "flex flex-col justify-between border-2 rounded-[15px] min-h-[22vh] w-[12vw] mx-[1.5vh] shadow-[2px_2px_8px_gray]";
  const cardNum = "text-3xl italic";
  const cardText = "mt-[4vh] mx-[1vw] text-xl font-bold";
  const cardIcon = "flex items-end justify-end m-[0_1vh_1vh_0]";

export function PreConselho() {
    const navigate = useNavigate();
    const [searchParams] = useSearchParams();
    const idTurma = searchParams.get('turma');
    const nomeTurma = searchParams.get('nomeTurma');
    const nomeEmpresa = searchParams.get('');

    const [modalObsAberto, setModalObsAberto] = useState(false);
    const [alunoSelecionadoObs, setAlunoSelecionadoObs] = useState(null);



    // Usuário logado vindo do localStorage (para registrar quem iniciou)
    const usuario = JSON.parse(localStorage.getItem('usuarioLogado') || '{}');
    const idUsuario = usuario.idUsuario;

    // conselhoId vem do backend (lookup por turma com fallback para sessão
    // do usuário). Sem localStorage — evita "vazamento" entre usuários.
    const [conselhoId, setConselhoId] = useState(null);
    const [donoConselho, setDonoConselho] = useState(null);

    const [modoEdicao, setModoEdicao] = useState(false);
        
    // Ciclo (semestre/ano) corrente — usado para reusar/abrir conselho no mesmo período
    const ciclo = useState(cicloAtual)[0];
    const [alunos, setAlunos] = useState([]);
    const [alunosSelecionados, setAlunosSelecionados] = useState([]);
    const [carregando, setCarregando] = useState(false);
    const [carregandoConselho, setCarregandoConselho] = useState(false); 
    const [alunosAvaliados, setAlunosAvaliados] = useState({}); 
     // Avaliações vindas do Conselho Intermediário do MESMO ciclo (histórico)
    const [historicoIntermediario, setHistoricoIntermediario] = useState({});       
    const [aguardandoConfirmacao, setAguardandoConfirmacao] = useState(false);

    // Estado que controla se o modal está aberto ou não
    const [isModalOpen, setIsModalOpen] = useState(false);

    // Existe um conselho rodando?
    const conselhoAtivo = !!conselhoId;

    // O usuário logado é o dono deste conselho? Quando não é, mostramos aviso
    // e o botão de finalizar pede confirmação reforçada.
    const naoEhDono = !!(donoConselho && donoConselho.idUsuario && donoConselho.idUsuario !== idUsuario);

    // Regras de habilitação (centralizadas aqui pra ficar fácil de manter):
    //  - botoesDesabilitados: bloqueia tudo enquanto o conselho não for iniciado
    //  - podeAvaliarAlunos: precisa ter conselho +  alunos marcados
    const botoesDesabilitados = !modoEdicao;

    const podeAvaliarAlunos =
        modoEdicao && alunosSelecionados.length > 0;

    // O botão principal (Iniciar/Finalizar) só fica bloqueado se está
    // carregando OU se não tem turma/usuário para iniciar
    const botaoPrincipalDesabilitado =
        carregandoConselho || aguardandoConfirmacao ||(!conselhoAtivo && (!idTurma || !idUsuario));

    const textoBotaoPrincipal = carregandoConselho
    ? 'Carregando...'
    : modoEdicao
        ? 'Finalizar Conselho'
        : conselhoAtivo
            ? 'Editar Conselho'
            : 'Iniciar Conselho';    



    // Funções para manipular o estado
    const handleOpenModal = () => {
        if (!podeAvaliarAlunos) return; 
        setIsModalOpen(true);
    }


    const handleCloseModal = () => setIsModalOpen(false);

    const handleVerObservacoes = async (aluno) => {
        try {
            // Busca na rota dinâmica recém-criada
            const idDoAluno = aluno.idtblAluno || aluno.id; 
            const res = await authFetch(`${API.observacoes}/aluno/${idDoAluno}`);
            const data = await res.json();

            if (data.sucesso) {
            const observacoesFormatadas = data.observacoes.map(o => {
                const dataObj = new Date(o.dataObservacao);
                return {
                id: o.idObservacao_Docente,
                texto: o.descricao,
                data: dataObj.toLocaleDateString('pt-BR', { timeZone: 'UTC' }),
                docente: o.docente
                };
            });

            setAlunoSelecionadoObs({
                nome: aluno.nome,
                observacoes: observacoesFormatadas
            });
            setModalObsAberto(true);
            } else {
            toast.error('Não há observações registradas para este aluno.');
            }
        } catch (error) {
            console.error("Erro ao buscar observações:", error);
            toast.error('Erro de conexão ao buscar observações.');
        }
        };

    const recarregarConselho = useCallback(async (cid, tid) => {
        if (!cid || !tid) return;
        try {
            const respA = await authFetch(`${API.conselho}/${cid}/turma/${tid}/avaliacoes-alunos`).then(r => r.json());

            const mapa = {};
            (respA?.avaliacoes || []).forEach(a => {
                mapa[a.tblAluno_idtblAluno] = a;
            });
            setAlunosAvaliados(mapa);
        } catch (e) {
            console.error('Erro ao recarregar pré-conselho:', e);
        }
    }, []);


    useEffect(() => {
        if(!idTurma) return;
        setAlunosAvaliados({});
        setAlunosSelecionados([]);
        setHistoricoIntermediario({});
        setCarregando(true);
        
        // Busca alunos e observações em paralelo
        Promise.all([
            authFetch(`${API.alunos}/empresa/${idTurma}`).then(res => res.json()),
            authFetch(`${API.observacoes}/turma/${idTurma}`).then(res => res.json())
        ])
        .then(([dataAlunos, dataObs]) => {
            if (dataAlunos.sucesso) {
                const listaObs = dataObs.sucesso ? dataObs.observacoes : [];
                // Cruza alunos com observações
                const alunosComObs = dataAlunos.alunos.map(aluno => {
                    // CORREÇÃO AQUI: Garante pegar o ID certo e usa "==" para ignorar se é String ou Number
                    const idAluno = aluno.idtblAluno || aluno.id;
                    const qtd = listaObs.filter(o => o.tblAluno_idtblAluno == idAluno).length;
                    return { ...aluno, qtdObservacoes: qtd };
                });
                setAlunos(alunosComObs);
            }
        })
        .finally(() => setCarregando(false));

        // Busca histórico do Conselho Intermediário do MESMO ciclo (semestre+ano)
        authFetch(`${API.conselho}/historico-intermediario/turma/${idTurma}?semestre=${ciclo.semestre}&ano=${ciclo.ano}`)
            .then(res => res.json())
            .then(data => {
                if (!data?.sucesso) return;
                const mapa = {};
                (data.avaliacoes || []).forEach(a => {
                    mapa[a.tblAluno_idtblAluno] = a;
                });
                setHistoricoIntermediario(mapa);
            })
            .catch(err => console.error('Erro ao buscar histórico do intermediário:', err));
    }, [idTurma, ciclo.semestre, ciclo.ano]);

    // 1b) Ao trocar de turma: localiza o conselho do ciclo (turma primeiro,
    // depois sessão do usuário) e vincula a turma de forma idempotente.
    useEffect(() => {
        if (!idTurma || !idUsuario) return;

        let cancelado = false;
        (async () => {
            // Reset apenas dos dados da TURMA. NÃO reseta modoEdicao — uma
            // vez iniciado o pré-conselho, o usuário continua em edit mode
            // ao navegar entre as próprias turmas. O reset acontece só
            // quando /ativo não acha conselho ou quando o usuário Finaliza.
            setAlunosAvaliados({});
            setAlunosSelecionados([]);

            try {
                // 1. Existe pré-conselho do ciclo para esta turma?
                const r1 = await authFetch(
                    `${API.conselho}/ativo/${encodeURIComponent('Pré-Conselho')}/turma/${idTurma}` +
                    `?idUsuario=${idUsuario}&semestre=${ciclo.semestre}&ano=${ciclo.ano}`
                );
                const d1 = await r1.json();
                if (cancelado) return;

                if (!d1?.sucesso || !d1.conselho) {
                    setConselhoId(null);
                    setDonoConselho(null);
                    setModoEdicao(false);
                    return;
                }

                // 2. Vincula a turma de forma idempotente (parâmetros completos).
                const r2 = await authFetch(`${API.conselho}/iniciar`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        tipoConselho: 'Pré-Conselho',
                        idTurma,
                        idUsuario,
                        semestre: ciclo.semestre,
                        ano: ciclo.ano,
                    }),
                });
                const d2 = await r2.json();
                if (cancelado) return;

                const cidFinal = (d2?.sucesso && d2.conselhoId) || d1.conselho.idConselho;
                const dono = d2?.dono || (d1.conselho.Usuario_idUsuario ? {
                    idUsuario: d1.conselho.Usuario_idUsuario,
                    nomeUsuario: d1.conselho.nomeUsuario,
                } : null);

                setConselhoId(cidFinal);
                setDonoConselho(dono);

                // modoEdicao só é setado por clique do usuário (Iniciar/Editar).
                // Não forçamos aqui: após F5/relogin, o usuário vê "Editar
                // Conselho" e clica para entrar em modo edição. Dentro da
                // sessão, modoEdicao persiste entre trocas de turma.

                // 3. Carrega avaliações.
                await recarregarConselho(cidFinal, idTurma);
            } catch (err) {
                console.error('Erro ao localizar/vincular pré-conselho:', err);
            }
        })();

        return () => { cancelado = true; };
    }, [idTurma, idUsuario, ciclo.semestre, ciclo.ano, recarregarConselho]);

    // Iniciar / Finalizar conselho
    const handleIniciarConselho = async () => {
        if (!idTurma || !idUsuario) {
            alert('Selecione uma turma e faça login para iniciar o conselho.');
            return;
        }
        setCarregandoConselho(true);
        try {
            const resp = await authFetch(`${API.conselho}/iniciar`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                tipoConselho: 'Pré-Conselho',
                idTurma,
                idUsuario,
                semestre: ciclo.semestre,
                ano: ciclo.ano
                })
            });
            const dados = await resp.json();
            if (!dados.sucesso) throw new Error(dados.mensagem);
            setConselhoId(dados.conselhoId);
            setDonoConselho(dados.dono || null);
            setModoEdicao(true);

        } catch (e) {
            console.error(e);
            alert('Erro ao iniciar conselho.');
        } finally {
            setCarregandoConselho(false);
        }
    };

    const handleEditarConselho = async () => {
        if (!conselhoId || !idTurma || !idUsuario) return;
        setCarregandoConselho(true);
        try {
            const resp = await authFetch(`${API.conselho}/iniciar`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    tipoConselho: 'Pré-Conselho',
                    idTurma,
                    idUsuario,
                    semestre: ciclo.semestre,
                    ano: ciclo.ano
                })
            });
            const dados = await resp.json();
            if (!dados.sucesso) throw new Error(dados.mensagem);

            // Garante consistência do ID local com o retorno do backend
            const idFinal = dados.conselhoId || conselhoId;
            if (idFinal !== conselhoId) {
                setConselhoId(idFinal);
            }
            if (dados.dono) setDonoConselho(dados.dono);

            await recarregarConselho(idFinal, idTurma);
            setModoEdicao(true);
        } catch (e) {
            console.error(e);
            alert('Erro ao editar conselho.');
        } finally {
            setCarregandoConselho(false);
        }
    };

    const handleFinalizarConselho = async () => {
        if (!conselhoId) return;

        setAguardandoConfirmacao(true);

        const mensagem = naoEhDono
            ? `Você não é o dono deste pré-conselho (iniciado por ${donoConselho?.nomeUsuario || 'outro usuário'}). Finalizar mesmo assim?`
            : 'Deseja finalizar o conselho?';

        toast(mensagem, {
          action: {
              label: "FINALIZAR",
              onClick: () => executarFinalizacao(),
          },
          cancel: {
              label: "CANCELAR",
              onClick: () => setAguardandoConfirmacao(false),
          },
          onDismiss: () => setAguardandoConfirmacao(false),    // ← libera se fechar
          onAutoClose: () => setAguardandoConfirmacao(false),  // ← libera se expirar
          duration: 8000,

        });
      };

    const executarFinalizacao = async () => {
        setAguardandoConfirmacao(false);
        setCarregandoConselho(true);

        try {
            const resp = await authFetch(`${API.conselho}/finalizar`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ conselhoId })
            });

            const dados = await resp.json();
            if (!dados.sucesso) throw new Error(dados.mensagem);

            // Sai do modo de edição mas mantém conselhoId/dono/avaliações
            // na tela. O botão vira "Editar Conselho" — se precisar mexer
            // em algum aluno depois, clica em Editar e o /iniciar reabre.
            setModoEdicao(false);
            toast.success('Conselho finalizado com sucesso!');

        } catch (e) {
            console.error(e);
            toast.error('Erro ao finalizar conselho.');
        } finally {
            setCarregandoConselho(false);
        }
    };
    
    const handleAcaoBotaoPrincipal = () => {
        if (modoEdicao) return handleFinalizarConselho();
        if (conselhoAtivo) return handleEditarConselho();
        return handleIniciarConselho();
      };

    const handleToogleAluno = (id) => {
        setAlunosSelecionados(prev => 
            prev.includes(id) ? prev.filter(a => a !== id) : [...prev, id]
        );
    };

    const handleSelecionarTudo = (e) => {
        if (e.target.checked) {
        setAlunosSelecionados(alunos.map(a => a.idtblAluno));
        } else {
        setAlunosSelecionados([]);
        }
    };

    const handleLimparSelecao = () => setAlunosSelecionados([]);

    const onSalvarAvaliacaoAlunos = async () => {
        setIsModalOpen(false);
        setAlunosSelecionados([]);
        await recarregarConselho(conselhoId, idTurma);
    };

    const totalRestritos = Object.keys(alunosAvaliados).length;

    const totalObs = alunos.reduce((acc, aluno) => acc + (aluno.qtdObservacoes || 0), 0);


    const tableThClasses = "border-b-2 border-t-2 border-r-2 first:border-l-2 border-gray-400 p-[12px_15px] font-bold bg-white sticky top-0 z-10";
    const tableTdClasses = "border-b-2 border-r-2 first:border-l-2 border-gray-400 p-[12px_15px] text-lg";

    // Classes do botão principal baseadas no estado atual
    const classeBotaoPrincipal = botaoPrincipalDesabilitado
        ? 'opacity-50 cursor-not-allowed bg-gray-400 text-white'
        : modoEdicao
            ? 'bg-red-900 text-white cursor-pointer active:scale-95 hover:bg-red-700'
            : conselhoAtivo
                ? 'bg-red-700 text-white cursor-pointer active:scale-95 hover:bg-red-800'
                : 'bg-green-600 text-white cursor-pointer active:scale-95 hover:bg-green-700';
 
  return (
      <section className='h-auto h-[92vh] gap-[1vh] mx-[1vw]'>
      <nav className="my-[1vh]">
        <span className="text-sm text-gray-500">
          <button
            onClick={() => navigate('/dashboard')}
            className="hover:underline text-gray-500"
          >
            Conselhos
          </button>
          {' / '}
          <span className="font-medium text-gray-700">Pré-Conselho / {nomeTurma}</span>
        </span>
      </nav>

      {naoEhDono && (
        <div className="bg-amber-50 border border-amber-300 text-amber-900 rounded-md px-4 py-2 text-sm mx-[1vw] mb-2">
          <strong>Iniciado por {donoConselho?.nomeUsuario || 'outro usuário'}.</strong>{' '}
          Você está visualizando o pré-conselho de outro responsável. Alterações
          serão registradas em seu nome. Evite finalizar sem combinar com o dono.
        </div>
      )}
        <div className="flex flex-col min-w-[72vw] my-5 ">
            <div className="flex justify-between">
                <div className={`${cardInfo} bg-white border-gray-800`}>
                    <div className={`${cardText}`}>
                        <h3 className={`${cardNum}`}>{alunos.length}</h3>
                        <p className="text_total_alunos">Total de Alunos</p>
                    </div>
                    <div className={`${cardIcon}`}>
                        <img src={totalAlunosIcon} alt="" className="w-10"/>
                    </div>
                </div>
                <div className={`${cardInfo} bg-green-50 border-green-600`}>
                    <div className={`${cardText} text-green-600`}>
                        <h3 className={`${cardNum}`}>{Math.max(0, alunos.length - totalRestritos)}</h3>
                        <p className="text_situacao_normal">Situação Normal</p>
                    </div>
                    <div className={`${cardIcon}`}>
                        <img src={situacaoNormalIcon} alt=""className="w-10" />
                    </div>
                </div>
                <div className={`${cardInfo} bg-yellow-50 border-yellow-600`}>
                    <div className={`${cardText} text-yellow-600`}>
                        <h3 className={`${cardNum}`}>{totalObs}</h3>
                        <p className="text_restritos">Total Observações</p>
                    </div>
                    <div className={`${cardIcon}`}>
                        <img src={restritosIcon} alt="" className="w-10"/>
                    </div>
                </div>
                <div className={`${cardInfo} bg-red-50 border-[var(--red-senai)]`}>
                    <div className={`${cardText} text-[var(--red-senai)]`}>
                        <h3 className={`${cardNum}`}>{totalRestritos}</h3>
                        <p className="text_retidos">Alunos Restritos</p>
                    </div>
                    <div className={`${cardIcon}`}>
                        <img src={retidosIcon} alt="" className="w-10"/>
                    </div>
                </div>
                <div className="card_avaliacoes">
            <div className="flex flex-col gap-7 min-h-[220px]">
                <button
                  onClick={handleAcaoBotaoPrincipal}
                  disabled={botaoPrincipalDesabilitado}
                  className={`p-[10px] w-[350px] rounded-[15px] border-2 border-gray-600 shadow-[0_0_3px_black] transition-all duration-200 font-bold text-lg
                  ${classeBotaoPrincipal}`}>
                  {textoBotaoPrincipal}
              </button>

                <button onClick={handleLimparSelecao}  disabled={botoesDesabilitados}  className={`limpar_selecao p-[10px] w-[350px] rounded-[15px] border-2 border-gray-600 shadow-[0_0_3px_black] transition-all duration-200 
                    ${botoesDesabilitados ? 'opacity-50 cursor-not-allowed bg-gray-100' : 'bg-white cursor-pointer active:scale-95'}`}>
                    Limpar Seleção
                </button>
                <button
                onClick={handleOpenModal}
                disabled={!podeAvaliarAlunos}
                title={
                    !conselhoAtivo || !modoEdicao
                        ? 'Inicie o conselho para avaliar alunos'
                        : alunosSelecionados.length === 0
                            ? 'Selecione ao menos um aluno'
                            : ''
                }
                className={`p-[10px] w-[350px] rounded-[15px] border-2 border-gray-600 shadow-[0_0_3px_black] transition-all duration-200
                ${!podeAvaliarAlunos
                    ? 'opacity-50 cursor-not-allowed bg-gray-100'
                    : 'bg-red-600 text-white cursor-pointer active:scale-95'}`}>
                Avaliar Selecionados
            </button>
            </div>
                {/* Renderiza o Modal passando o estado e a função de fechar */}
                <ModalAvaliacao 
                isOpen={isModalOpen} 
                onClose={handleCloseModal}
                conselhoId={conselhoId}
                idUsuario={idUsuario}
                alunosSelecionados={alunosSelecionados.map(id => ({
                    id,
                    nome: alunos.find(a => a.idtblAluno === id)?.nome,
                    avaliacaoExistente: alunosAvaliados[id] || null,
                    historicoIntermediario: historicoIntermediario[id] || null
                }))}
                onSaved={onSalvarAvaliacaoAlunos} />
                </div>
            </div>
        </div>
        
            <div className="flex flex-col">
                <div className="flex justify-between my-0 text-xl ">
                    <div className="flex gap-2">
                        <input onChange={handleSelecionarTudo} disabled={botoesDesabilitados} type="checkbox" id="checkbox_selecionar_tudo" className="w-5 h-5 cursor-pointer"
                        checked={alunos.length > 0 && alunosSelecionados.length === alunos.length} />
                        <p>Selecionar Tudo</p>
                    </div>
                    <div className="quatidade_alunos_selecionados">
                        <p>Alunos Selecionados: {alunosSelecionados.length}</p>
                    </div>
                </div>

                <section className='max-h-[50vh] overflow-y-auto'>
                    {!carregando && (
                        
                    <table className="w-full bg-white text-md box-border border-separate border-spacing-0 shadow-[0_0_4px_gray]">
                        <thead>
                        <tr>
                            <th className={`${tableThClasses} w-[40%] text-center`}>Aluno</th>
                            <th className={`${tableThClasses} w-[14%] text-center`}>Observações</th>
                            <th className={`${tableThClasses} w-[22%] text-center`}>Empresa</th>
                            <th className={`${tableThClasses} w-[12%] text-center`}>1° Conselho</th>
                            <th className={`${tableThClasses} w-[12%] text-center`}>2° Conselho</th>
                        </tr>
                        </thead>
                    
                        <tbody className='divide-y divide-gray-200'>
                        {/* O map fica AQUI, apenas para gerar as linhas (tr) da tabela */}
                        {alunos.map((aluno) => {
                            const restritoAtual= !!alunosAvaliados[aluno.idtblAluno];
                            const restritoHistorico = !!historicoIntermediario[aluno.idtblAluno];
                            const restrito = restritoAtual;
                    
                            return (
                            <tr key={aluno.idtblAluno}>
                    
                                {/* Coluna 1: Aluno */}
                                <td className={`${tableTdClasses}`}>
                                <label className='flex items-center gap-2 m-0 cursor-pointer'>
                                    <input
                                    disabled={botoesDesabilitados}
                                    type="checkbox"
                                    className='w-5 h-5 cursor-pointer'
                                    checked={alunosSelecionados.includes(aluno.idtblAluno)}
                                    onChange={() => handleToogleAluno(aluno.idtblAluno)}
                                    />
                                    <p className="text-xl">{aluno.nome}</p>
                                </label>
                                </td>
                                {/* Coluna 2: Observações */}
                                <td className={`${tableTdClasses}`}>
                                  {aluno.qtdObservacoes > 0 ? (
                                    <button 
                                        onClick={() => handleVerObservacoes(aluno)} 
                                        className='text-gray-500 text-xs hover:underline flex flex-col items-center mx-auto'
                                    >
                                        <div className="flex items-center my-0 mx-1 gap-1">
                                        <img src={notificationIcon} alt="" className="w-6 h-6 p-[1px]"/>
                                        <div className='flex'>
                                            <p className="text-sm underline text-orange-700 whitespace-nowrap">Ver Observações ({aluno.qtdObservacoes})</p>
                                        </div>
                                        </div>
                                    </button>
                                  ) : (
                                    <div className="text-center text-gray-400 font-bold">-</div>
                                  )}
                                </td>
                                {/* Coluna 3: Empresa */}
                                <td className={`${tableTdClasses}`}>
                                    <p className="text-xl text-center">{aluno.nomeEmpresa || "-"}</p>

                                </td>

                                {/* Coluna 4: Restrito - C.I */}
                                <td className={`${tableTdClasses} text-center`}>
                                    <div className="div_label_restrito_ci">
                                        {restritoHistorico && (
                                        <label className="text-lg text-white font-bold bg-red-800 px-4 py-2 rounded-full">
                                            Restrito
                                        </label>
                                        )}
                                    </div>
                                </td>

                                {/* Coluna 5: Restrito */}
                                <td className={`${tableTdClasses} text-center`}>
                                <div className="div_btn_restrito">
                                    {restrito && (
                                    <label className="text-lg text-white font-bold bg-red-800 px-4 py-2 rounded-full">
                                        Restrito
                                    </label>
                                    )}
                                </div>
                                </td>
                    
                            </tr>
                            );
                        })}
                        </tbody>
                    </table>
                    )}
                </section>
            </div>
            <ModalObservacoes
            isOpen={modalObsAberto}
            onClose={() => { setModalObsAberto(false); setAlunoSelecionadoObs(null); }}
            aluno={alunoSelecionadoObs}
            somenteLeitura={true} // <-- Aqui garante que o ADMIN não possa alterar nem deletar nada!
        />
      </section>
      
      
  );
}